from __future__ import annotations

import asyncio
import time
from typing import Literal, override

import anyio
import js
import orjson

import async_kernel
from async_kernel.interface.interface import InterfaceBase
from async_kernel.typing import Job, Message, MsgType, SocketID


class Pyodide_Interface(InterfaceBase):


    async def start(self, options: dict):

        kernel = async_kernel.Kernel()

        async def run_kernel():
            async with kernel:
                await anyio.sleep_forever()

        self._task = asyncio.create_task(run_kernel())
        await kernel.event_started

    @override
    def _send_to_frontend(self, msg: Message):
        if "channel" not in msg:
            msg["channel"] = "shell"  # pyright: ignore[reportGeneralTypeIssues]
        buffers = msg.pop('buffers', None)
        msg_string = orjson.dumps(
            msg, option=orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_PASSTHROUGH_DATETIME, default=repr
        ).decode()
        js.postMessage({"msg_string": msg_string, "buffers": buffers or []})

    async def _send_reply(self, job: Job, content: dict) -> None:
        if "status" not in content:
            content["status"] = "ok"
        msg = job["msg"]
        msg["channel"] = job["socket_id"].name  # pyright: ignore[reportGeneralTypeIssues]
        self._send_to_frontend(
            self.msg(
                msg_type=job["msg"]["header"]["msg_type"].replace("request", "reply"),
                content=content,
                parent=job["msg"],
            )
        )

    def on_msg(self, msg_string: str, buffers: list[bytes | bytearray]):
        msg: Message = orjson.loads(msg_string)
        msg["buffers"] = buffers
        socket_id: Literal[SocketID.shell, SocketID.control] = SocketID(msg.get("channel", SocketID.shell))  # pyright: ignore[reportAssignmentType]
        try:
            subshell_id = msg["content"]["subshell_id"]
        except KeyError:
            try:
                subshell_id = msg["header"]["subshell_id"]
            except KeyError:
                subshell_id = None
        job = Job(received_time=time.monotonic(), socket_id=socket_id, msg=msg, ident=b"")
        self.kernel.msg_handler(
            subshell_id, socket_id, MsgType(job["msg"]["header"]["msg_type"]), job, self._send_reply
        )

